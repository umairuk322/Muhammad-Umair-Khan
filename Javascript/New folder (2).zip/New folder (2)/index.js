let btn = document.getElementById("btn")
let content = document.getElementById("content")
let dots = document.getElementById("dots")

function toggleContent(){
    if(btn.innerHTML==="Read More"){
        btn.innerHTML = "Show Less"
        content.innerHTML = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam saepe repudiandae eos qui exercitationem rerum tempora. Minima, doloribus. Suscipit placeat tenetur illo est quae enim corrupti eos sint officia architecto, nihil, adipisci saepe magni ducimus, consequatur ratione. Suscipit quisquam voluptates consequatur. Dolorem sapiente, dignissimos et sit nihil nulla magni soluta distinctio? Harum iure magnam labore fugit maxime, sunt nesciunt, numquam quae magni cum dolorum cupiditate minima neque? Id rerum nihil soluta iusto consectetur porro aliquam velit odio, voluptatem tenetur cum sunt dolores, aliquid repellat in magnam veniam temporibus vero. Sapiente in, error vel a quae, magnam doloremque voluptatem recusandae consequatur, autem dolores! Ea dolores rem illum recusandae ipsa error magnam odit similique laborum expedita labore, dignissimos fuga praesentium voluptas dolor quos quidem exercitationem nulla, eius sequi illo totam autem! Omnis assumenda quo adipisci amet voluptas similique vel alias, numquam quod animi. Architecto doloremque temporibus eius porro veniam necessitatibus, officia, dolorum voluptates nobis repellat nesciunt accusamus eligendi quod! Quisquam cupiditate, asperiores illo corporis ab officia vero hic accusantium est voluptatibus voluptates beatae facere voluptas harum sapiente iste quos ducimus. Sunt nisi quisquam reiciendis aperiam, mollitia deleniti, explicabo maxime exercitationem corporis asperiores possimus officia perferendis obcaecati odio quidem, optio consequuntur id voluptatum!"
        
    }
    else{
        btn.innerHTML = "Read More"
        content.innerHTML = content.innerHTML.substring(0, 11)
       }
       
    

    
}
toggleContentO()
